# Upgrading to Project Factory v16.0

The v16.0 release of Project Factory is a backwards incompatible release.

### Google Cloud Platform Provider upgrade

The Project Factory module now requires version `5.33` or higher of the Google Cloud Platform Provider and `5.33` or higher of the Google Cloud Platform Beta Provider.
