# Upgrading to Project Factory v15.0

The v15.0 release of Project Factory is a backwards incompatible release.

### Google Cloud Platform Provider upgrade

The Project Factory module now requires version 5.22 or higher of the Google Cloud Platform Provider and 5.22 or higher of
the Google Cloud Platform Beta Provider.
