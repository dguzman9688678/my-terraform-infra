# Upgrading to SQL DB 17.0.0

The 16.0.0 release of SQL DB is a backward incompatible release.

This update requires upgrading the minimum provider version from `4.74` to `4.80`.
